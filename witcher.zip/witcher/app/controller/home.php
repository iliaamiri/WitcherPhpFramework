<?php
namespace Controller;

use Core\controller;

class home extends controller {
    public function index(){

        parent::setViews(['welcome.php']);
        parent::Show();
    }
}