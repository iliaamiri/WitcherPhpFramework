<?php

namespace Controller;

use Core\controller;
use modelObjects\gateway;
use modelObjects\transaction;
use modelObjects\transaction_form;
use Module\bridgeValidation;
use Module\gatewayModulesDiagnosis;
use Module\getGatewayFromTransaction;

class selenium extends controller
{

    private static $webdriver;
    private static $messages;

    public function load($invoice_key){
        parent::setData(['invoice_key' => $invoice_key ,'url' => HTTPS_SERVER."/invoice/payy/".$invoice_key]);
        parent::setViews(['ajax_loader.php']);
        parent::Show();
    }

    public function start($invoice_key = "")
    {
        try {
            $witcher = new \witcher();
            $witcher->requireModules('/seleniumPayment/');
            $witcher->requireModules('/bank_gateway/');
            self::$messages = array_merge($witcher->getExceptionsMessages('gateway_request.php'),$witcher->getExceptionsMessages("selenium.php"));
            if ($invoice_key == "cancel" and !isset($_SESSION['invoice_key'])) {
                throw new \Exception(json_encode(['status' => 0,'errorCode' => '200','errorDescription' => self::$messages['ErrorCode_200']]));
            } elseif ($invoice_key == null and $invoice_key != "cancel") {
                throw new \Exception(json_encode(['status' => 0,'errorCode' => '200','errorDescription' => self::$messages['ErrorCode_200']]));
            } elseif ($invoice_key == "cancel" and isset($_SESSION['invoice_key'])) {
                $trans_info = new transaction($_SESSION['invoice_key']);
                $trans_form = new transaction_form($trans_info->getIdByInvoice_key($_SESSION['invoice_key']));
                if (!$trans_form->exists()) {
                    throw new \Exception(json_encode(['status' => 0,'errorCode' => '200','errorDescription' => self::$messages['ErrorCode_200']]));
                }
                $trans_form->update('attempt_num_cancel',$trans_form->attempt_num_cancel + 1);
                $trans_info->update('status',-11);
                session_destroy();
                $getGatewayFromTransaction = new getGatewayFromTransaction($trans_info);
                $gateway = $getGatewayFromTransaction->getGateway();
                if (time() - $trans_info->creation_time > $gateway->selenium_timeout_limit) {
                    $trans_form->update('last_error_user_saw', self::$messages['payment_token_expired'] . " at line " . __LINE__ . " controller-selenium");
                    header("location:" . HTTPS_SERVER . "/tokenExpired?u=" . $trans_info->invoice_key);
                    exit();
                }
                self::$webdriver = unserialize($trans_info->WAITASEC);
                self::$webdriver->close();

                $trans_form->update('last_error_user_saw', self::$messages['transaction_canceled_by_user'] . " at line " . __LINE__ . " controller-selenium");
                header("location:" . HTTPS_SERVER . "/TransactionCanceled?u=" . $trans_info->invoice_key);
                exit();
            }

            $trans_info = new transaction($invoice_key);

            if (!$trans_info->exists()) {
                throw new \Exception(json_encode(['status' => 0,'errorCode' => '200','errorDescription' => self::$messages['ErrorCode_200']]));
            }

            $getGatewayFromTransaction = new getGatewayFromTransaction($trans_info);
            $gateway = $getGatewayFromTransaction->getGateway();
            if (!$gateway->valid) {
                throw new \Exception(json_encode(['status' => 0,'errorCode' => '101','errorDescription' => self::$messages['ErrorCode_101']]));
            }

            $os_br = new \OS_BR();
            $last_browser = $os_br->getBrowser();
            $last_os = $os_br->getOS();

            $trans_info->update('last_browser_used',$last_browser);
            $trans_info->update('last_os_used',$last_os);

            $bridgeValidation_module = new bridgeValidation($trans_info->bridged_id,$trans_info->selenium_server_id,$gateway,$trans_info->amount);
            $bridgeValidation_module->Validate();
            $gateway = $bridgeValidation_module->getGateway();

            $gatewayModulesDiagnosis = new gatewayModulesDiagnosis($gateway);
            $gatewayModulesDiagnosis->Diagnosis();

            $moduleName = '\Module\\' . $gatewayModulesDiagnosis->moduleName;
            $seleniumGateway_module = new $moduleName();

            $seleniumGateway_module->Run($invoice_key);

            parent::setData($seleniumGateway_module->data);
            parent::setViews($seleniumGateway_module->view);
            parent::Show();
        } catch (\Exception $exception) {
            header("refresh:0;url=" . HTTPS_SERVER . "/404");
            session_destroy();
        }
    }

    public function browserCleanHandler()
    {
        $timeout_in_seconds = 660;
        $execution_started_at = time();

        $transactionModel = new \Model\transaction();

        $sql_select_results = $transactionModel->custom_select_for_browser_cleaning_selenium($timeout_in_seconds,$execution_started_at);

        $closed = 0;
        $total = count($sql_select_results);
        foreach($sql_select_results as $result){
            if ($result){
                unserialize($result)->close();
                $closed++;
            }
        }
        $transactionModel->close_browser_cleaning($timeout_in_seconds,$execution_started_at);

        echo $total." records have been selected.<br>";
        echo $closed." records are surely closed.<br>";
        echo "Execution Started At (Timestamp) : ".$execution_started_at;
    }


}