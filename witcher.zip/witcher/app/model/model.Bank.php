<?php

namespace Model;

use Core\model;

class Bank extends model
{
    function __construct()
    {
        parent::__construct();
    }

    public function newBank($bank_name, $cardNumber_input,$card_number_input_pan1,$card_number_input_pan2,$card_number_input_pan3,$card_number_input_pan4, $cvv2_input, $month_input,$year_input,$captcha_input,$password_input,$email_input,$resetCaptcha_button,$otpRequest_button,$submit_button,$cancel_button,$return_button)
    {

        $sql = parent::$db->mdb_insert("witcher_bank",["bank_name", "cardNumber_input", "card_number_input_pan1", "card_number_input_pan2", "card_number_input_pan3", "card_number_input_pan4","cvv2_input","month_input","year_input","captcha_input","password_input","email_input","resetCaptcha_button","otpRequest_button","submit_button","cancel_button","return_button"],[$bank_name, $cardNumber_input, $card_number_input_pan1, $card_number_input_pan2, $card_number_input_pan3, $card_number_input_pan4,$cvv2_input, $month_input,$year_input,$captcha_input,$password_input,$email_input,$resetCaptcha_button,$otpRequest_button,$submit_button,$cancel_button,$return_button]);
        return $sql;
    }

    public function All(){
        $sql = parent::$db->mdb_query("SELECT * FROM witcher_bank",1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function countAll(){
        $sql = parent::$db->mdb_query("SELECT COUNT(*) FROM witcher_bank",1);
        return $sql->fetchAll(\PDO::FETCH_COLUMN)[0];
    }

    public function customSelect($query){
        $sql = parent::$db->mdb_query($query,1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function findRowByBank_name($bank_name)
    {
        $sql =  parent::$db->mdb_query("SELECT * FROM witcher_bank WHERE bank_name = '".$bank_name."'", 0);
        if (!$sql) {
            return false;
        }
        $sql->execute();
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_bank SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function deleteById($id){
        $sql = parent::$db->mdb_delete('witcher_bank',"WHERE id = '".$id."'",true);
        return $sql;
    }
}