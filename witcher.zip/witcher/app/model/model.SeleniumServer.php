<?php

namespace Model;

use Core\model;

class SeleniumServer extends model
{
    public function findRowById($id)
    {
        try {
            $sql = parent::$db->mdb_query("SELECT * FROM witcher_selenium_server WHERE id = :id", 0);
            $sql->bindValue(':id', $id, \PDO::PARAM_INT);
            $sql->execute();
        } catch (\PDOException $e) {
            var_dump($e); // bayad vardashte shavad
            die();
        }

        if (!$sql) {
            return false;
        }
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_selenium_server SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function deleteById($id)
    {
        $sql = parent::$db->mdb_delete('witcher_selenium_server', "WHERE id = '" . $id . "'", true);
        return $sql;
    }
}