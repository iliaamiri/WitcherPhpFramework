<?php
namespace Model;

use Core\model;

class GatewayTypes extends model{
    public function findRowByType_id($type_id){
        try{
            $sql = parent::$db->mdb_query("SELECT * FROM witcher_gateway_types WHERE type_id = :type_id",0);
            $sql->bindValue(':type_id',$type_id,\PDO::PARAM_STR);
            $sql->execute();
        }catch(\PDOException $e){
            var_dump($e);
            die();
        }

        if (!$sql){
            return false;
        }
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0){
            return false;
        }
        return $response[0];
    }
}