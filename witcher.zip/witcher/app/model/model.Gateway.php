<?php

namespace Model;

use Core\model;

class Gateway extends model
{
    public function findRowByApi_key($api_key)
    {
        try {
            $sql = parent::$db->mdb_query("SELECT
  t2.id,
  t2.type,
  t2.api_key,
  t1.target_server,
  t3.server_host          selenium_server,
  t3.server_port          selenium_port,
  t3.server_timeout_limit selenium_timeout,
  t2.suitcase_id,
  t5.submit_attempt_limit,
  t5.otpRequest_attempt_limit,
  t5.resetCaptcha_attempt_limit,
  t2.bridge_number,
  t2.transaction_amountLimit_byCardNumber,
  t4.bank_name,
  t2.descriptions
FROM witcher_gateway t2
  JOIN witcher_gateway_target_server t1 ON t1.id = t2.target_server_id
  JOIN witcher_selenium_server t3 ON t3.id = t2.selenium_server_id
  JOIN witcher_bank t4 ON t2.bank_id = t4.id
  JOIN witcher_gateway_limitation t5 ON t5.id = t2.limitation_id
WHERE t2.api_key = :api_key", 0);
            $sql->bindValue(':api_key', $api_key, \PDO::PARAM_STR);
            $sql->execute();
        } catch (\PDOException $e) {
            var_dump($e);
            die();
        }
        if (!$sql) {
            return false;
        }
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }


}