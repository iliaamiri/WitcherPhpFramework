<?php

namespace Model;

use Core\model;

class GatewayTargetServer extends model
{
    function __construct()
    {
        parent::__construct();
    }

    public function newTargetServer($target_server)
    {
        $sql = parent::$db->mdb_insert("witcher_gateway_target_server",["target_server"],[$target_server]);
        return $sql;
    }

    public function all(){
        $sql = parent::$db->mdb_query("SELECT * FROM witcher_gateway_target_server",1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function countAll(){
        $sql = parent::$db->mdb_query("SELECT COUNT(*) FROM witcher_gateway_target_server",1);
        return $sql->fetchAll(\PDO::FETCH_COLUMN)[0];
    }

    public function findRowById($id)
    {
        $sql =  parent::$db->mdb_query("SELECT target_server FROM witcher_gateway_target_server WHERE id = '".$id."'", 1);
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_gateway_target_server SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function deleteById($id){
        $sql = parent::$db->mdb_delete('witcher_gateway_target_server',"WHERE id = '".$id."'",true);
        return $sql;
    }
}