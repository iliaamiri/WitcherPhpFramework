<?php

namespace Model;

use Core\model;
use Core\preg;

class TransactionBlockedCardnumber extends model
{
    function __construct()
    {
        parent::__construct();
    }

    public function findRowByCardnumber($card_number)
    {
        parent::$preg->return_after = false;
        parent::$preg->push($card_number, 'number');

        $sql = (preg::$preg_status == true) ? parent::$db->mdb_query("SELECT * FROM witcher_transaction_blocked_cardnumbers WHERE cardNumber = :card_number", 0) : false;
        if (!$sql) {
            return false;
        }
        $sql->execute(array(':card_number' => $card_number));
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_transaction_form SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }
}