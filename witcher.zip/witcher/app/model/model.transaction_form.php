<?php

namespace Model;

use Core\model;
use Core\preg;

class transaction_form extends model
{
    function __construct()
    {
        parent::__construct();
    }

    public function newTransactionForm($transaction_Id,$auto_filling_cardNumber,$auto_filling_cvv2,$auto_filling_month,$auto_filling_year,$auto_filling_captcha,$auto_filling_password,$auto_filling_email){
        $sql = parent::$db->mdb_query("INSERT INTO witcher_transaction_form (transaction_Id,auto_filling_cardNumber,auto_filling_cvv2,auto_filling_month,auto_filling_year,auto_filling_captcha,auto_filling_password,auto_filling_email) VALUES ('".$transaction_Id."','".$auto_filling_cardNumber."','".$auto_filling_cvv2."','".$auto_filling_month."','".$auto_filling_year."','".$auto_filling_captcha."','".$auto_filling_password."','".$auto_filling_email."')", 1);
        return $sql;
    }

    public function findRowByTransaction_Id($transaction_Id)
    {
        parent::$preg->return_after = false;
        parent::$preg->push($transaction_Id, 'number');

        $sql = (preg::$preg_status == true) ? parent::$db->mdb_query("SELECT * FROM witcher_transaction_form WHERE transaction_Id = :transaction_Id", 0) : false;
        if (!$sql) {
            return false;
        }
        $sql->execute(array(':transaction_Id' => $transaction_Id));
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_transaction_form SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function advancedUpdateRow($transaction_Id,$last_submit_status,$last_submit_time,$last_otpRequest_time,$last_resetCaptcha_time,$last_captcha_user_saw,$last_error_user_saw,$attempt_num_submit,$attempt_num_otpRequest,$attempt_num_resetCaptcha,$attempt_num_cancel,$last_post_params,$submitted_cardNumber,$submitted_cvv2,$submitted_month,$submitted_year,$submitted_captcha,$submitted_password,$submitted_email,$auto_filling_cardNumber,$auto_filling_cvv2,$auto_filling_month,$auto_filling_year,$auto_filling_captcha,$auto_filling_password ,$auto_filling_email){
        $sql = parent::$db->mdb_update('witcher_transaction_form',['transaction_Id','last_submit_status','last_submit_time','last_otpRequest_time','last_resetCaptcha_time','last_captcha_user_saw','last_error_user_saw','attempt_num_submit','attempt_num_otpRequest','attempt_num_resetCaptcha','attempt_num_cancel','last_post_params','submitted_cardNumber','submitted_cvv2','submitted_month','submitted_year','submitted_captcha','submitted_password','submitted_email','auto_filling_cardNumber','auto_filling_cvv2','auto_filling_month','auto_filling_year','auto_filling_captcha','auto_filling_password','auto_filling_email'],[$transaction_Id,$last_submit_status,$last_submit_time,$last_otpRequest_time,$last_resetCaptcha_time,$last_captcha_user_saw,$last_error_user_saw,$attempt_num_submit,$attempt_num_otpRequest,$attempt_num_resetCaptcha,$attempt_num_cancel,$last_post_params,$submitted_cardNumber,$submitted_cvv2,$submitted_month,$submitted_year,$submitted_captcha,$submitted_password,$submitted_email,$auto_filling_cardNumber,$auto_filling_cvv2,$auto_filling_month,$auto_filling_year,$auto_filling_captcha,$auto_filling_password ,$auto_filling_email]," WHERE transaction_Id = '".$transaction_Id."'");
        return $sql;
    }

    public function getSumAmount_byCardnumber($cardnumber){
        $sql = parent::$db->mdb_query("SELECT SUM(witcher_transaction.amount) AS value_sum FROM witcher_transaction_form INNER JOIN witcher_transaction
      ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE (witcher_transaction_form.submitted_cardNumber = '".$cardnumber."' OR witcher_transaction_form.auto_filling_cardNumber = '".$cardnumber."') AND witcher_transaction.status = '1' AND witcher_transaction.TEST = 'verified'",1);
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (!isset($response[0])){
            return 0;
        }
        return $response[0]['value_sum'];
    }
}