<?php

namespace Model;

use Core\model;

class BridgeTable extends model
{
    public function findRowByBridge_number($bridge_number)
    {
        try {
            $sql = parent::$db->mdb_query("
            SELECT 
            t1.id,
            t1.amount_limiting,
            t1.min_amount,
            t1.max_amount,
            t1.type,
            t1.transaction_amountLimit_byCardNumber,
            t1.descriptions,
            t2.target_server,
            t3.server_host,
            t3.server_port,
            t3.server_timeout_limit,
            t4.submit_attempt_limit,
            t4.otpRequest_attempt_limit,
            t4.resetCaptcha_attempt_limit,
            t5.bank_name
            FROM witcher_bridge t1
            JOIN witcher_gateway_target_server t2 ON t2.id = t1.bridge_target_server_id
            JOIN witcher_selenium_server t3 ON t3.id = t1.selenium_server_id
            JOIN witcher_gateway_limitation t4 ON t4.id = t1.limitation_id
            JOIN witcher_bank t5 ON t5.id = t1.bank_id
            WHERE t1.id = :bridge_number", 0);
            $sql->bindValue(':bridge_number', $bridge_number, \PDO::PARAM_STR);
            $sql->execute();
            if (!$sql) {
                return false;
            }
            $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
            if (count($response) == 0) {
                return false;
            }
            return $response[0];
        } catch (\PDOException $e) {
            var_dump($e);
        }
    }
}