<?php

namespace Model;

use Core\model;

class GatewaySuitcase extends model
{
    public $got_selenium_server_id = false;
    public $got_bridge_id = false;

    public function findRowById($id)
    {
        try {
            $sql = parent::$db->mdb_query("SELECT * FROM witcher_gateway_suitcase WHERE id = :id", 0);
            $sql->bindValue(':id', $id, \PDO::PARAM_INT);
            $sql->execute();
        } catch (\PDOException $e) {
            var_dump($e); // bayad vardashte shavad
            die();
        }

        if (!$sql) {
            return false;
        }
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function getRandomGatewayToBalance($api_key, $amount)
    {
        $sql = parent::$db->mdb_query("CALL getSeleniumServerAndGatewayBridgeId(".$amount.",'".$api_key."')", 1);
        $sql_result = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($sql_result) == 0) {
            return false;
        }
        $sql_result = $sql_result[0];

        $selenium_server_id = $sql_result['selenium_server_id'];
        $gateway_bridge_id = $sql_result['gateway_bridge_id'];
        $sql->closeCursor();
        if ($gateway_bridge_id == 0){
            $this->got_selenium_server_id = true;
            return ['selenium_server_id' => $selenium_server_id];
        }

        $sql3 = parent::$db->mdb_query("SELECT
  bridge.id,
  t2.id selenium_server_id,
  bridge.type,
  t4.target_server,
  t2.server_host          selenium_server,
  t2.server_port          selenium_port,
  t2.server_timeout_limit selenium_timeout,
  bank.bank_name,
  t6.submit_attempt_limit,
  t6.otpRequest_attempt_limit,
  t6.resetCaptcha_attempt_limit,
  bridge.transaction_amountLimit_byCardNumber,
  bridge.descriptions
FROM witcher_bridge bridge
  JOIN witcher_selenium_server t2 ON t2.id = " . $selenium_server_id . "
  JOIN witcher_gateway_target_server t4 ON t4.id = bridge.bridge_target_server_id
  JOIN witcher_bank bank ON bank.id = bridge.bank_id
  JOIN witcher_gateway_limitation t6 ON t6.id = bridge.limitation_id
WHERE bridge.id = " . $gateway_bridge_id, 0);
        $sql3->execute();
        $sql3_result = $sql3->fetchAll(\PDO::FETCH_ASSOC);
        $sql3->closeCursor();
        if (count($sql3_result) == 0) {
            return false;
        }
        $sql3_result = $sql3_result[0];
        $sql3_result['api_key'] = $api_key;

        $this->got_bridge_id = true;
        $this->got_selenium_server_id = true;
        return $sql3_result;
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_gateway_suitcase SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function deleteById($id)
    {
        $sql = parent::$db->mdb_delete('witcher_gateway_suitcase', "WHERE id = '" . $id . "'", true);
        return $sql;
    }

    public function deleteByApiKey($api_key)
    {
        $sql = parent::$db->mdb_delete('witcher_gateway_suitcase', "WHERE api_key = '" . $api_key . "'", true);
        return $sql;
    }
}