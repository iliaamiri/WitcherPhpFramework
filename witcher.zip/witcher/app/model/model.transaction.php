<?php

namespace Model;

use Core\model;
use Core\preg;

class transaction extends model
{
    function __construct()
    {
        parent::__construct();
    }

    public function newTransaction($invoice_key, $bridged_id, $selenium_server_id, $amount, $return_url, $api_key)
    {
        $os_br = new \OS_BR();
        $last_browser = $os_br->getBrowser();
        $last_os = $os_br->getOS();

        $sql = parent::$db->mdb_query("INSERT INTO witcher_transaction (invoice_key,api_key,bridged_id,selenium_server_id,amount,return_url,creation_time,last_user_ip,last_browser_used,last_os_used) VALUES ('" . $invoice_key . "','" . $api_key . "','".$bridged_id."','".$selenium_server_id."','" . $amount . "',:return_url,'" . time() . "','" . $_SERVER['REMOTE_ADDR'] . "' , '" . $last_browser . "','" . $last_os . "')", 0);
        $sql->execute(array(':return_url' => $return_url));
        return ;
    }

    public function existsCV($column,$value){
        $sql = parent::$db->mdb_query("SELECT witcher_transaction.*, witcher_transaction_form.* FROM witcher_transaction INNER JOIN witcher_transaction_form ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE $column = :bindedvalue",0);
        $sql->bindValue(':bindedvalue',$value,\PDO::PARAM_STR);
        $sql->execute();
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getIdByInvoice_key($invoice_key){
        $sql = parent::$db->mdb_query("SELECT witcher_transaction.id FROM witcher_transaction WHERE invoice_key = '".$invoice_key."'",1);
        $result = $sql->fetchAll(\PDO::FETCH_COLUMN);
        if ($result == null){
            return 0;
        }else {
            return $result[0];
        }
    }

    public function findRowByInvoice_key($invoice_key)
    {
        parent::$preg->return_after = false;
        parent::$preg->push($invoice_key, 'username');

        $sql = (preg::$preg_status == true) ? parent::$db->mdb_query("SELECT * FROM witcher_transaction WHERE invoice_key = :invoice_key", 0) : false;
        if (!$sql) {
            return false;
        }
        $sql->execute(array(':invoice_key' => $invoice_key));
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) == 0) {
            return false;
        }
        return $response[0];
    }

    public function All()
    {
        $sql = parent::$db->mdb_query("SELECT witcher_transaction.* , witcher_transaction_form.* FROM witcher_transaction INNER JOIN witcher_transaction_form ON witcher_transaction.id = witcher_transaction_form.transaction_Id", 1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function countAll(){
        $sql = parent::$db->mdb_query("SELECT COUNT(*) FROM witcher_transaction",1);
        $result = $sql->fetchAll(\PDO::FETCH_COLUMN);
        if ($result == null){
            return 0;
        }else {
            return $result[0];
        }
    }

    public function customSelect($query)
    {
        $sql = parent::$db->mdb_query($query, 1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function updateRow($column, $value, $query)
    {
        $sql = parent::$db->mdb_query("UPDATE witcher_transaction SET " . $column . " = ? " . $query, 0);
        $sql->execute([$value]);
    }

    public function advancedUpdateRow($invoice_key_where, $invoice_key, $api_key, $amount, $return_url, $creation_time, $status, $last_user_ip, $last_browser_used, $last_os_used, $WAITASEC, $bank_code, $TEST)
    {
        $sql = parent::$db->mdb_update('witcher_transaction', ['invoice_key', 'api_key', 'amount', 'return_url', 'creation_time', 'status', 'last_user_ip', 'last_browser_used', 'last_os_used', 'WAITASEC', 'bank_code', 'TEST'], [$invoice_key, $api_key, $amount, $return_url, $creation_time, $status, $last_user_ip, $last_browser_used, $last_os_used, $WAITASEC, $bank_code, $TEST], " WHERE invoice_key = '" . $invoice_key_where . "'");
        return $sql;
    }

    public function sumAmountCardNumberToday($cardNumber)
    {
        $timestamp_now = time();
        $timestamp_first_of_the_day = strtotime(date("Y-m-d"), $timestamp_now);

        $sql = parent::$db->mdb_query("SELECT
  SUM(t1.amount) amount
FROM witcher_transaction t1
JOIN witcher_transaction_form t2 ON t1.id = t2.transaction_Id
WHERE t2.submitted_cardNumber = '".$cardNumber."' AND (t1.creation_time BETWEEN $timestamp_first_of_the_day AND $timestamp_now)");
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        $amount = 0;
        if (isset($response['amount'])){
            $amount = $response['amount'];
        }
        return $amount;
    }

    public function maximumeSumPayGear($timestamp, $api_key)
    {
        $sql = parent::$db->mdb_query("SELECT SUM(amount) AS value_sum FROM witcher_transaction api_key = " . $api_key . " AND bank_code IS NOT NULL AND " . $timestamp);
        $response = $sql->fetchAll(\PDO::FETCH_ASSOC);
        if (count($response) > 0){
            return $response[0]["value_sum"];
        }
        return 0;
    }

    public function generateRandomInvoiceKey()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < rand(10, 16); $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $invoice_key = rand(123456, 1234567) . "_" . $randomString;
        return $invoice_key;
    }

    public function deleteByInvoiceKey($invoice_key)
    {
        $sql = parent::$db->mdb_delete('witcher_transaction', "WHERE invoice_key = '" . $invoice_key . "'", true);
        if ($sql) {
            return true;
        }
        return false;
    }

    public function close_browser_cleaning($timeout_in_seconds,$execution_started_at){
        parent::$db->mdb_query("UPDATE witcher_transaction SET browser_status = 0 WHERE browser_status = 1 AND  ".$execution_started_at." - creation_time > ".$timeout_in_seconds , 1);
    }

    public function custom_select_for_browser_cleaning_selenium($timeout_in_seconds,$execution_started_at){
        $sql_select = parent::$db->mdb_query("SELECT WAITASEC FROM witcher_transaction WHERE browser_status = 1 AND  ".$execution_started_at." - creation_time > ".$timeout_in_seconds , 1);

        return $sql_select->fetchAll(\PDO::FETCH_COLUMN);
    }

    public function getCreated_at_by_day_and_apiKey($day = 0,$api_key,$success = true)
    {
        $timestamp_now = strtotime(date("Y-m-d"), time());

        $timestamp_first_of_the_day = $timestamp_now + ($day * 86400);
        $timestamp_end_of_the_day = $timestamp_now + (($day + 1) * 86400);

        $addOn_query = "";
        if ($success){
            $addOn_query = "(witcher_transaction.bank_code IS NOT NULL OR witcher_transaction.bank_code != ' ') AND ";
        }

        $sql = parent::$db->mdb_query("SELECT witcher_transaction.* , witcher_transaction_form.* FROM witcher_transaction INNER JOIN witcher_transaction_form
      ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE ".$addOn_query." witcher_transaction.api_key = '".$api_key."' AND witcher_transaction.creation_time BETWEEN $timestamp_first_of_the_day AND " . $timestamp_end_of_the_day, 1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getCreated_at_by_month_and_apiKey($month = 0,$api_key,$success = true){
        $timestamp_now = strtotime(date("Y-m-d"), time());

        $timestamp_first_of_the_month = $timestamp_now + ($month * 2592000);
        $timestamp_end_of_the_month = $timestamp_now + (($month + 1) * 2592000);

        $addOn_query = "";
        if ($success){
            $addOn_query = "(witcher_transaction.bank_code IS NOT NULL OR witcher_transaction.bank_code != ' ') AND ";
        }

        $sql = parent::$db->mdb_query("SELECT witcher_transaction.* , witcher_transaction_form.* FROM witcher_transaction INNER JOIN witcher_transaction_form
      ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE ".$addOn_query." witcher_transaction.api_key = '".$api_key."' AND witcher_transaction.creation_time BETWEEN $timestamp_first_of_the_month AND " . $timestamp_end_of_the_month, 1);
        return $sql->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function getSum_Amount_by_day_and_apiKey($day = 0,$api_key,$success = true){
        $timestamp_now = strtotime(date("Y-m-d"), time());

        $timestamp_first_of_the_day = $timestamp_now + ($day * 86400);
        $timestamp_end_of_the_day = $timestamp_now + (($day + 1) * 86400);

        $addOn_query = "";
        if ($success){
            $addOn_query = "(witcher_transaction.bank_code IS NOT NULL OR witcher_transaction.bank_code != ' ') AND ";
        }

        $sql = parent::$db->mdb_query("SELECT SUM(witcher_transaction.amount) as value_sum FROM witcher_transaction INNER JOIN witcher_transaction_form
      ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE ".$addOn_query." witcher_transaction.api_key = '".$api_key."' AND witcher_transaction.creation_time BETWEEN $timestamp_first_of_the_day AND " . $timestamp_end_of_the_day, 1);
        return $sql->fetch(\PDO::FETCH_ASSOC)['value_sum'];
    }

    public function getSum_Amount_by_month_and_apiKey($month = 0,$api_key,$success = true){
        $timestamp_now = strtotime(date("Y-m-d"), time());

        $timestamp_first_of_the_month = $timestamp_now + ($month * 2592000);
        $timestamp_end_of_the_month = $timestamp_now + (($month + 1) * 2592000);

        $addOn_query = "";
        if ($success){
            $addOn_query = "(witcher_transaction.bank_code IS NOT NULL OR witcher_transaction.bank_code != ' ') AND ";
        }

        $sql = parent::$db->mdb_query("SELECT SUM(witcher_transaction.amount) as value_sum FROM witcher_transaction INNER JOIN witcher_transaction_form
      ON witcher_transaction.id = witcher_transaction_form.transaction_Id WHERE ".$addOn_query." witcher_transaction.api_key = '".$api_key."' AND witcher_transaction.creation_time BETWEEN $timestamp_first_of_the_month AND " . $timestamp_end_of_the_month, 1);
        return $sql->fetch(\PDO::FETCH_ASSOC)['value_sum'];
    }
}