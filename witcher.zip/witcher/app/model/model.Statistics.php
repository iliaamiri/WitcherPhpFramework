<?php
namespace Model;

use Core\model;

class Statistics extends model {

}