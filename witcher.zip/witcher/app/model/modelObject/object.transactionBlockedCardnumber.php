<?php
namespace modelObjects;

class transactionBlockedCardnumber extends \Model\TransactionBlockedCardnumber {
    public $valid = false;

    public $id;
    public $card_number;
    public $blocked_at;


    function __construct($card_number)
    {
        parent::__construct();

        $row = $this->findRowByCardnumber($card_number);
        if ($row){
            $this->id = $row['id'];
            $this->card_number = $row['cardNumber'];
            $this->blocked_at = $row['blocked_at'];

            $this->valid = true;
        }
    }

    public function update($var_to_update, $new_value)
    {
        $this->updateRow($var_to_update, $new_value, " WHERE cardNumber = '" . $this->card_number . "'");
    }
}