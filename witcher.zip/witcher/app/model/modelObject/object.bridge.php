<?php
namespace modelObjects;

use Model\BridgeTable;

class bridge extends BridgeTable {
    public $valid = false;

    public $id;
    public $type;
    public $amount_limiting;
    public $min_amount;
    public $max_amount;
    public $bridge_target_server;
    public $selenium_server;
    public $selenium_port;
    public $selenium_timeout_limit;
    public $bank_name;
    public $submit_attempt_limit;
    public $resetCaptcha_attempt_limit;
    public $otpRequest_attempt_limit;
    public $bridge_number;
    public $transaction_amountLimit_byCardNumber;
    public $descriptions;

    function __construct($bridge_number)
    {
        parent::__construct();

        $row = $this->findRowByBridge_number($bridge_number);

        if (!$row){
            $this->valid = false;
        }else{
            $this->id = $row['id'];
            $this->type = $row['type'];
            $this->amount_limiting = $row['amount_limiting'];
            $this->min_amount = $row['min_amount'];
            $this->max_amount = $row['max_amount'];
            $this->bridge_target_server = $row['target_server'];
            $this->selenium_server = $row['server_host'];
            $this->selenium_port = $row['server_port'];
            $this->selenium_timeout_limit = $row['server_timeout_limit'];
            $this->submit_attempt_limit = $row['submit_attempt_limit'];
            $this->otpRequest_attempt_limit = $row['otpRequest_attempt_limit'];
            $this->resetCaptcha_attempt_limit = $row['resetCaptcha_attempt_limit'];
            $this->bank_name = $row['bank_name'];
            $this->transaction_amountLimit_byCardNumber = $row['transaction_amountLimit_byCardNumber'];
            $this->descriptions = $row['descriptions'];

            $this->valid = true;
        }
    }


}