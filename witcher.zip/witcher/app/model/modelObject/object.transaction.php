<?php
namespace modelObjects;

class transaction extends \Model\transaction {
    private $exist = true;

    public $id;
    public $invoice_key;
    public $bridged_id;
    public $selenium_server_id;
    public $api_key;
    public $amount;
    public $return_url;
    public $creation_time;
    public $status;
    public $last_user_ip;
    public $last_browser_used;
    public $last_os_used;
    public $WAITASEC;
    public $bank_code;
    public $TEST;


    function __construct($invoice_key)
    {
        parent::__construct();

        $row = $this->findRowByInvoice_key($invoice_key);
        if (!$row){
            $this->exist = false;
        }else{
            $this->id = $row['id'];
            $this->invoice_key = $row['invoice_key'];
            $this->bridged_id = $row['bridged_id'];
            $this->selenium_server_id = $row['selenium_server_id'];
            $this->api_key = $row['api_key'];
            $this->amount = $row['amount'];
            $this->return_url = $row['return_url'];
            $this->creation_time = $row['creation_time'];
            $this->status = $row['status'];
            $this->last_user_ip = $row['last_user_ip'];
            $this->last_browser_used = $row['last_browser_used'];
            $this->last_os_used = $row['last_os_used'];
            $this->WAITASEC = $row['WAITASEC'];
            $this->bank_code = $row['bank_code'];
            $this->TEST = $row['TEST'];
        }
    }

    public function exists(){
        return $this->exist;
    }

    public function update($var_to_update, $new_value)
    {
        $this->updateRow($var_to_update, $new_value, " WHERE invoice_key = '" . $this->invoice_key . "'");
    }
}