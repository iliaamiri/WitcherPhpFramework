<?php
namespace modelObjects;


class gateway extends \Model\Gateway {
    public $valid = false;

    public $id;
    public $type;
    public $api_key;
    public $target_server;
    public $selenium_server;
    public $selenium_port;
    public $selenium_timeout_limit;
    public $bank_name;
    public $submit_attempt_limit;
    public $resetCaptcha_attempt_limit;
    public $otpRequest_attempt_limit;
    public $bridge_number;
    public $suitcase_id;
    public $transaction_amountLimit_byCardNumber;
    public $descriptions;

    function __construct($api_key)
    {
        parent::__construct();

        $row = $this->findRowByApi_key($api_key);

        if (!$row){
            $this->valid = false;
        }else{
            $this->id = $row['id'];
            $this->type = $row['type'];
            $this->api_key = $api_key;
            $this->target_server = $row['target_server'];
            $this->selenium_server = $row['selenium_server'];
            $this->selenium_port = $row['selenium_port'];
            $this->selenium_timeout_limit = $row['selenium_timeout'];
            $this->bank_name = $row['bank_name'];
            $this->submit_attempt_limit = $row['submit_attempt_limit'];
            $this->resetCaptcha_attempt_limit = $row['resetCaptcha_attempt_limit'];
            $this->otpRequest_attempt_limit = $row['otpRequest_attempt_limit'];
            $this->bridge_number = $row['bridge_number'];
            $this->suitcase_id = $row['suitcase_id'];
            $this->transaction_amountLimit_byCardNumber = $row['transaction_amountLimit_byCardNumber'];
            $this->descriptions = $row['descriptions'];

            $this->valid = true;
        }
    }


}