<?php

namespace modelObjects;

class transaction_form extends \Model\transaction_form
{
    private $exist = true;

    public $id;
    public $transaction_Id;
    public $last_submit_status;
    public $last_submit_time;
    public $last_otpRequest_time;
    public $last_resetCaptcha_time;
    public $last_captcha_user_saw;
    public $last_error_user_saw;
    public $attempt_num_submit;
    public $attempt_num_otpRequest;
    public $attempt_num_resetCaptcha;
    public $attempt_num_cancel;
    public $last_post_params;
    public $submitted_cardNumber;
    public $submitted_cvv2;
    public $submitted_month;
    public $submitted_year;
    public $submitted_captcha;
    public $submitted_password;
    public $submitted_email;
    public $auto_filling_cardNumber;
    public $auto_filling_cvv2;
    public $auto_filling_month;
    public $auto_filling_year;
    public $auto_filling_captcha;
    public $auto_filling_password;
    public $auto_filling_email;


    function __construct($transaction_Id)
    {
        parent::__construct();

        $row = $this->findRowByTransaction_Id($transaction_Id);
        if (!$row) {
            $this->exist = false;
        } else {
            $this->id = $row['id'];
            $this->transaction_Id = $row['transaction_Id'];
            $this->last_submit_status = $row['last_submit_status'];
            $this->last_submit_time = $row['last_submit_time'];
            $this->last_otpRequest_time = $row['last_otpRequest_time'];
            $this->last_resetCaptcha_time = $row['last_resetCaptcha_time'];
            $this->last_captcha_user_saw = $row['last_captcha_user_saw'];
            $this->last_error_user_saw = $row['last_error_user_saw'];
            $this->attempt_num_submit = $row['attempt_num_submit'];
            $this->attempt_num_otpRequest = $row['attempt_num_otpRequest'];
            $this->attempt_num_resetCaptcha = $row['attempt_num_resetCaptcha'];
            $this->attempt_num_cancel = $row['attempt_num_cancel'];
            $this->last_post_params = $row['last_post_params'];
            $this->submitted_cardNumber = $row['submitted_cardNumber'];
            $this->submitted_cvv2 = $row['submitted_cvv2'];
            $this->submitted_month = $row['submitted_month'];
            $this->submitted_year = $row['submitted_year'];
            $this->submitted_captcha = $row['submitted_captcha'];
            $this->submitted_password = $row['submitted_password'];
            $this->submitted_email = $row['submitted_email'];
            $this->auto_filling_cardNumber = $row['auto_filling_cardNumber'];
            $this->auto_filling_cvv2 = $row['auto_filling_cvv2'];
            $this->auto_filling_month = $row['auto_filling_month'];
            $this->auto_filling_year = $row['auto_filling_year'];
            $this->auto_filling_captcha = $row['auto_filling_captcha'];
            $this->auto_filling_password = $row['auto_filling_password'];
            $this->auto_filling_email = $row['auto_filling_email'];
        }
    }

    public function exists()
    {
        return $this->exist;
    }

    public function update($var_to_update, $new_value)
    {
        $this->updateRow($var_to_update, $new_value, " WHERE transaction_Id = '" . $this->transaction_Id . "'");
    }
}