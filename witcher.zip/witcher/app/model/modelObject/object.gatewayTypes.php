<?php
namespace modelObjects;

class gatewayTypes extends \Model\GatewayTypes {
    public $valid = false;

    public $type_title;
    public $type_id;
    public $module_name;
    public $method_cancelPayment;
    public $method_submitPayButton;
    public $method_statusAssess;
    public $method_otpRequest;
    public $method_resetCaptcha;
    public $method_connection;
    public $method_makeRequest;
    public $method_invoiceCheck;
    public $active;

    function __construct($type_id)
    {
        parent::__construct();

        $row = $this->findRowByType_id($type_id);

        if (!$row){
            $this->valid = false;
        }else{
            $this->type_title = $row['type_title'];
            $this->type_id = $row['type_id'];
            $this->module_name = $row['module_name'];
            $this->method_cancelPayment = $row['method_cancelPayment'];
            $this->method_submitPayButton = $row['method_submitPayButton'];
            $this->method_statusAssess = $row['method_statusAssess'];
            $this->method_otpRequest = $row['method_otpRequest'];
            $this->method_resetCaptcha = $row['method_resetCaptcha'];
            $this->method_connection = $row['method_connection'];
            $this->method_makeRequest = $row['method_makeRequest'];
            $this->method_invoiceCheck = $row['method_invoiceCheck'];
            $this->active = $row['active'];
            $this->valid = true;
        }
    }
}