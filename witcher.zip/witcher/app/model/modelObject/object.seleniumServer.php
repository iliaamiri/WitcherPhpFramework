<?php
namespace modelObjects;

class seleniumServer extends \Model\SeleniumServer {
    public $valid = false;

    public $id;
    public $server_host;
    public $server_port;
    public $server_timeout_limit;

    function __construct($id)
    {
        parent::__construct();

        $row = $this->findRowById($id);

        if (!$row){
            $this->valid = false;
        }else{
            $this->id = $row['id'];
            $this->server_host = $row['server_host'];
            $this->server_port = $row['server_port'];
            $this->server_timeout_limit = $row['server_timeout_limit'];

            $this->valid = true;
        }
    }


}