<?php
namespace modelObjects;

class bank extends \Model\Bank {
    public $valid = false;

    public $bank_name;
    public $cardNumber_input;
    public $card_number_input_pan1;
    public $card_number_input_pan2;
    public $card_number_input_pan3;
    public $card_number_input_pan4;

    public $cvv2_input;
    public $month_input;
    public $year_input;
    public $captcha_input;
    public $password_input;
    public $email_input;
    public $resetCaptcha_button;
    public $otpRequest_button;
    public $submit_button;
    public $cancel_button;
    public $return_button;

    function __construct($bank_name)
    {
        parent::__construct();

        $row = $this->findRowByBank_name($bank_name);

        if (!$row){
            $this->valid = false;
        }else{
            $this->bank_name = $row['bank_name'];
            $this->cardNumber_input = $row['cardNumber_input'];
            $this->card_number_input_pan1 = $row['card_number_input_pan1'];
            $this->card_number_input_pan2 = $row['card_number_input_pan2'];
            $this->card_number_input_pan3 = $row['card_number_input_pan3'];
            $this->card_number_input_pan4 = $row['card_number_input_pan4'];

            $this->cvv2_input = $row['cvv2_input'];
            $this->month_input = $row['month_input'];
            $this->year_input = $row['year_input'];
            $this->captcha_input = $row['captcha_input'];
            $this->password_input = $row['password_input'];
            $this->email_input = $row['email_input'];
            $this->resetCaptcha_button = $row['resetCaptcha_button'];
            $this->otpRequest_button = $row['otpRequest_button'];
            $this->submit_button = $row['submit_button'];
            $this->cancel_button = $row['cancel_button'];
            $this->return_button = $row['return_button'];

            $this->valid = true;
        }
    }

    public function update($var_to_update, $new_value)
    {
        $this->updateRow($var_to_update, $new_value, " WHERE bank_name = '" . $this->bank_name . "'");
    }


}