<?php
namespace modelObjects;

class gatewayTargetServer extends \Model\GatewayTargetServer {
    public $valid = false;
    public $type;

    function __construct($id)
    {
        parent::__construct();

        $row = $this->findRowById($id);

        if (!$row){
            $this->valid = false;
        }else{
            $this->type = $row['target_server'];
            $this->valid = true;
        }
    }


}