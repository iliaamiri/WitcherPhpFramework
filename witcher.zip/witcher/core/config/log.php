<?php

return [
    'dates' => [
        'status' => true ,
        'log_day' => true ,
        'log_at_least_second' => true,
    ],
    'log_http_response_code' => true,
    'log_witcher_version' => true,
    'log_get' => false,
    'log_post' => false,
];