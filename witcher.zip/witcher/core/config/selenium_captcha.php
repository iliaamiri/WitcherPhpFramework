<?php
return [
    'Mellat' => [
        'crop_x' => '910',
        'crop_y' => '340',
        'height' => '46',
        'width' => '160'
    ],
    
    'Parsian' => [
        'crop_x' => '925',
        'crop_y' => '278',
        'height' => '35',
        'width' => '90'
    ],
    
    'Saderat' => [
        'crop_x' => '1100',
        'crop_y' => '351',
        'height' => '40',
        'width' => '166'
    ],
    
    'Pasargad' => [
        'crop_x' => '1132',
        'crop_y' => '266',
        'height' => '39',
        'width' => '100'
    ],
    
    'Irankish' => [
        'crop_x' => '1305',
        'crop_y' => '477',
        'height' => '35',
        'width' => '120'
    ],

    'AsanPardakht' => [
        'crop_x' => '1305',
        'crop_y' => '477',
        'height' => '35',
        'width' => '120'
    ],
    
    'Saman' => [
        'crop_x' => '1553',
        'crop_y' => '278',
        'height' => '50',
        'width' => '135'
    ],
];