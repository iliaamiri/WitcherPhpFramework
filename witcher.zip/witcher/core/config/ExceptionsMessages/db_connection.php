<?php

return [
    'connection_failed' => "Failed to connect to db",
    'db_not_found' => "database not found",
    'custom_db_not_found' => "Connection failed to the custom database",
    'unknown_table' => "This table does not exist.",
    'unknown_column' => "This column does not exist in this table.",
    'update_fail' => '',
    'insert_fail' => '',
    'delete_fail' => '',
    'select_fail' => ''
];