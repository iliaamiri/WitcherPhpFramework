<?php
return [
    
    'successful_otp_request' => 'رمز پویا ارسال شد',
    'failed_otp_request' => 'رمز پویا قبل تر برای شما ارسال شده',
    'user_failed_the_otp_request' => 'خطا رمز پویا',
    'otp_request_unkown_error' => 'خطا نامشخص رمز پویا',
    'selenium_backend_bugged' => 'خطای سرور، درحال انتقال به سایت پذیرنده',
    

];