<?php
return [
    'separator' => '|pWm6rgZaVs093nPu5Jez|'
];