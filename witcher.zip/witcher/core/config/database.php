<?php
return [
    'default' => [
        'dsn' => '',
        'db_driver' => 'mysql',
        'db_host' => 'localhost',
        'db_name' => 'clubs_configs',
        'db_login' => 'root',
        'db_pass' => '',
        'db_charset' => 'utf8',
        'application_log' => false
    ]
];