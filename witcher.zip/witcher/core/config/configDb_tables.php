<?php
return [
    'main_db' => 'main_database',
    'db_drivers_cats' => 'db_drivers_cats',
    'witcher_routes' => 'witcher_routes'
];