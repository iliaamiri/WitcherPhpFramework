<?php

return [
    'session_name' => "__gsrr",
    'session_secure' => false,
    'session_httponly' => true,
    'session_path' => '/',
    'session_limit' => 0
];