<?php

return [
    'use' => true ,
    'controllers' => ['ALL_CONTROLLERS'] ,
    'encryption_key' => 'AUTO' /* "AUTO" will generate it automatically */,
    'session_index_name' => 'CSRFToken_key'
];