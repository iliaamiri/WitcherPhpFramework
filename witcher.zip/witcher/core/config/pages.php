<?php
return [
    '443' => '/404.html',
    '404' => '/404',
    'login' => '/hello/administrator/login',
    'signup' => '/signup',
    'welcome' => '/',
    'home' => '/',
    'admin' => '/hello/administrator',
    'panel' => '/hello/administrator',
    'report' => '/report',
    'reportLogin' => '/report/login',
    'forgot_password' => '/forgot',
    'chatroom' => '/chatroom',
    'chatroom_lobby' => '/chatroom/lobby'
];
