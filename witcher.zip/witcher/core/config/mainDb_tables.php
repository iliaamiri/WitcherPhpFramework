<?php
return [
    'users' => 'user_tbl',
    'users_permissions' => 'user_permissions',
    'role_cat' => 'role_category',
    'user_permissions' => 'user_permissions',
    'bridge' => 'witcher_bridge',
    'witcher_gateway' => 'witcher_gateway',
    'witcher_invoices' => 'witcher_invoices',
];