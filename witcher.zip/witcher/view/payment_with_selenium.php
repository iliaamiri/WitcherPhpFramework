<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:title" content="پرداخت الکترونیکی به پرداخت ویچر"/>
    <meta property="og:url" content="<?= HTTP_SERVER ?>"/>
    <meta property="og:image" content="http://"/>
    <title>پرداخت الکترونیکی به پرداخت ویجر</title>
    <link href="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/img/ipg-favicon.png" rel="shortcut icon">
    <link href="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/css/esprit_fa.min.css" rel="stylesheet">
    <script src="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/msg/messages_fa.min.js"></script>
    <style>
        .close-button {
            background-color: #c2c7cc !important;
            background-image: url(/img/ipg-decline.svg) !important;
            width: 25px !important;
            height: 25px !important;
        }
        #OverlayLoading {
            position: fixed;
            display: none;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.78);
            z-index: 99999;
            cursor: pointer;
            text-align: center;
        }
        #text{
            position: absolute;
            width: 100%;
            top: 50%;
            left: 50%;
            color: white;
            transform: translate(-50%,-50%);
            -ms-transform: translate(-50%,-50%);
            text-align: center;
        }

        #myProgress {
            direction: ltr;
            width: 55%;
            background-color: grey;
            text-align: center!important;
            margin: 0 auto;
            margin-top:20px;
        }

        #myBar {
            height: 30px;
            background-color: #af3e2a;
            text-align: center; /* To center it horizontally (if you want) */
            line-height: 30px; /* To center it vertically */
            color: white;
        }
    </style>
    <script>
        invoice_key = "<?= \Core\controller::$data['invoice_key'] ?>";
        HTTP_SERVER = "<?=HTTP_SERVER?>";
    </script>
</head>
<body id="body" class="up-scroll" onclick="hideKeyPadOnOutsideClick(event);hideCardSuggestionListOnOutSideClick(event)">
<div id="OverlayLoading">
    <div id="text">
        <p style="text-align: center;font-size:22px;width: 90%;margin: 0 auto;">پرداخت درحال انجام است.. لطفا منتظر بمانید.</p>
        <div id="myProgress">
            <div id="myBar"></div>
        </div>
        <p style="font-size: 12px;margin-top: 20px;"><img src="<?= HTTPS_SERVER ?>/witcherAssets/loaderAssets/images/favicon.png" height="50px" alt="">
            WITCHER V<?= WITCHER_VERSION ?></p>
    </div>
</div>
<header id="header">
    <div class="container">
        <div class="beh-card">
            <div class="row">
                <div class="col shaparaklogo align-self-start">
                    <img
                         src="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/img/ipg-logo.png"
                         alt="WITCHER">
                </div>
                <div class="col-7 header-center align-self-end hidden-xs">
                    <h1>پرداخت الکترونیکی ویچر</h1><br>

                </div>
                <div class="col behpardakhtlogo align-self-start hidden-xs"></div>
            </div>
        </div>
    </div>
</header>
<div class="main-wrapper payment">
    <section class="container">
        <div class="row row-eq-height">
            <div class="col-lg-8 col-md-12 col-sm-12 order-lg-1 order-2">
                <div class="beh-card carddetail">
                    <div class="card-header">
                        <h3>اطلاعات کارت</h3>
                        <span id="remaining-time">زمان باقی مانده :<b><?= $_SESSION['time_remaining'] ?></b></span>
                        <span class="card-errorbox" style="height: auto;">لطفا اطلاعات مورد نیاز را به درستی وارد کنید</span>
                        <span class="card-errorbox-WitcherMessage" id="WitcherMessage" style="height: auto;"></span>
                    </div>
                    <div class="card-body">
                        <form class="card-info">
                            <div class="form-group row">
                                <div class="col-sm-4">
                                    <label for="cardnumber" class="col-form-label">شماره کارت</label>
                                    <small>شماره کارت 16 رقمی درج شده روی کارت را وارد نمایید</small>
                                </div>
                                <div class="col-md-6 col-sm-8 col-12 mobile-justify">
                                    <div class="cardnumberbox">
                                        <span class="banklogo"></span>
                                        <input type="tel" id="cardnumber" maxlength="19"
                                               onkeydown="preventInvalidKeys(event);setPanCursorPosition(event);"
                                               onkeyup="formatPanOnKeyUp(event);filterAndShowCardSuggestionList();setBankLogo();focusNextField(this,'inputcvv2',event);resetSelectedPan(event)"
                                               oninput="formatPanOnKeyUp(event);setBankLogo();focusNextField(this,'inputcvv2',event);resetSelectedPan(event)"
                                               onfocus="hideKeyPad();removeInvalidClassFromPan()"
                                               onblur="checkPanDiscount()"
                                               value="<?=\Core\controller::$data['trans_form_object']['auto_filling_cardNumber']?>"
                                               name="card-number"
                                            <?php if (\Core\controller::$data['trans_form_object']['auto_filling_cardNumber'] != ""){ ?>
                                                disabled="disabled"
                                            <?php } ?>
                                        >
                                        <button type="button" id="card-list-button" data-toggle="dropdown"
                                                onclick="toggleAllPans()"
                                                aria-haspopup="true" aria-expanded="false" tabindex="-1"></button>
                                        <div class="card-suggestionlist dropdown-menu"
                                             aria-labelledby="card-list-button">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4">
                                    <label for="inputcvv2" class="col-form-label">شماره شناسایی دوم (CVV2)</label>
                                    <small>شماره 3 یا 4 رقمی درج شده روی کارت را وارد نمایید</small>
                                </div>
                                <div class="col-md-3 col-sm-4 col-8  mobile-justify keypad-parent">
                                    <input type="password" class="form-control" id="inputcvv2" maxlength="4"

                                           onfocus="hideCardSuggestionList();removeInvalidClassFromInput('inputcvv2')"
                                           autocomplete="off"
                                           onkeydown="preventInvalidKeys(event);"
                                           onkeyup="focusNextField(this,'inputmonth|inputcapcha',event);"
                                           name="cvv2"
                                            value="<?=\Core\controller::$data['trans_form_object']['auto_filling_cvv2']?>"
                                            <?php if (\Core\controller::$data['trans_form_object']['auto_filling_cvv2'] != ""){?>
                                            disabled="disabled"
                                           <?php }?>>
                                </div>
                                <div class="col-sm-1">
                                    <button type="button" class="form-btn keypad" tabindex="-1"
                                            onclick="showKeyPad('inputcvv2',event)"></button>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4">
                                    <label for="inputmonth" class="col-form-label">تاریخ انقضای کارت</label>
                                    <small>تاریخ انقضای کارت را وارد کنید</small>
                                </div>
                                <div class="col-2 d-lg-none d-sm-none"></div>
                                <div class="col-md-2 col-sm-3 col-4">
                                    <input type="tel" class="form-control" id="inputmonth" maxlength="2"
                                           placeholder="ماه"
                                           autocomplete="off"
                                           onkeydown="preventInvalidKeys(event);"
                                           onfocus="hideKeyPad();removeInvalidClassFromInput('inputmonth')"
                                           onkeyup="focusNextField(this,'inputyear',event);"
                                           name="month"
                                           value="<?=\Core\controller::$data['trans_form_object']['auto_filling_month']?>"
                                        <?php if (\Core\controller::$data['trans_form_object']['auto_filling_month'] != ""){?>
                                            disabled="disabled"
                                        <?php }?>
                                    >
                                </div>
                                <div class="col-md-2 col-sm-3 col-4">
                                    <input type="tel" class="form-control" id="inputyear" maxlength="2"
                                           placeholder="سال"
                                           autocomplete="off"
                                           onfocus="removeInvalidClassFromInput('inputmonth')"
                                           onkeydown="preventInvalidKeys(event);"
                                           onkeyup="focusNextField(this,'inputcapcha',event)"
                                           name="year"
                                    value="<?=\Core\controller::$data['trans_form_object']['auto_filling_year']?>"
                                        <?php if (\Core\controller::$data['trans_form_object']['auto_filling_year'] != ""){?>
                                            disabled="disabled"
                                        <?php }?>
                                    >
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4">
                                    <label for="inputcapcha" class="col-form-label">کد امنیتی</label>
                                    <small>لطفا کد امنیتی داخل کادر را وارد نمایید</small>
                                </div>
                                <div class="col-sm-3 col-8 mobile-justify">
                                    <input type="tel" class="form-control" id="inputcapcha" maxlength="7"
                                           autocomplete="off"
                                           onfocus="removeInvalidClassFromInput('inputcapcha')"
                                           onkeydown="preventInvalidKeys(event);"
                                           onkeyup="focusNextField(this,'inputpin',event)"
                                           name="captcha"
                                           value="<?=\Core\controller::$data['trans_form_object']['auto_filling_captcha']?>"
                                        <?php if (\Core\controller::$data['trans_form_object']['auto_filling_captcha'] != ""){?>
                                            disabled="disabled"
                                        <?php }?>
                                    ></div>
                                <div class="col-sm-3 col-6 capcha-container mobile-justify">
                                    <img id="captcha-img"
                                         src="<?= HTTP_SERVER ?>/witcherAssets/captchaImages/<?php echo $_SESSION['captcha_filename'] . ".png?" . rand(100, 1000); ?>">
                                </div>
                                <div class="col-sm-1 col-4">
                                    <button type="button" class="form-btn capcha" title="نمايش تصوير جديد"
                                            onclick="refreshCaptcha()" id="refreshCaptcha_button"></button>
                                </div>
                            </div>
                            <div class="form-group row" onblur="hideKeypad()">
                                <div class="col-sm-4">
                                    <label for="inputpin" class="col-form-label">رمز اینترنتی کارت</label>
                                    <small>رمز اینترنتی را وارد نمایید</small>
                                </div>
                                <div class="col-md-6 col-sm-6 col-10 mobile-justify keypad-parent">
                                    <div class="cardnumberbox" id="dynamic-pin">
                                        <input type="password" class="form-control" id="inputpin" maxlength="12"
                                               onfocus="hideOthersKeypad(this);hideCardSuggestionList();removeInvalidClassFromInput('inputpin');"
                                               autocomplete="off" onkeydown="preventInvalidKeys(event);"
                                               onkeyup="focusNextField(this,'inputpayerid|payButton',event);"
                                                value="<?=\Core\controller::$data['trans_form_object']['auto_filling_password']?>"
                                            <?php if (\Core\controller::$data['trans_form_object']['auto_filling_password'] != ""){?>
                                                disabled="disabled"
                                            <?php }?>
                                        >
                                        <button type="button" id="otp-button" data-toggle="dropdown"
                                                onclick="validateAndRequestOTP()" aria-haspopup="true"
                                                aria-expanded="false" tabindex="-1">دریافت رمز پویا
                                        </button>
                                    </div>
                                </div>
                              <!--  <div class="col-sm-1 ">
                                    <button type="button" disabled class="form-btn keypad" tabindex="-1"
                                            onclick="showKeyPad('inputpin',event)"></button>
                                </div>
                              -->
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4">
                                    <label for="inputemail" class="col-form-label">ایمیل</label>
                                    <small>اختیاری</small>
                                </div>
                                <div class="col-md-6 col-sm-8 col-12 mobile-justify">
                                    <input type="email" class="form-control" id="inputemail"
                                           onfocus="removeInvalidClassFromInput('inputemail')"
                                    value="<?=\Core\controller::$data['trans_form_object']['auto_filling_email']?>"
                                        <?php if (\Core\controller::$data['trans_form_object']['auto_filling_email'] != ""){?>
                                            disabled="disabled"
                                        <?php }?>
                                    >
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4"></div>
                                <div class="col-md-6 col-sm-8 col-12 mobile-justify btn-submit-form">
                                    <button type="button" class="btn btn-perches" id="payButton"
                                            onclick="validateAndSale(event)">پرداخت
                                    </button>
                                    <button type="button" class="btn btn-decline" onclick="cancelPay()">انصراف</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 col-sm-12 order-lg-2 order--1">
                <div class="beh-card merchantdetail witcher-width">
                    <div class="card-header">
                        <h3>اطلاعات پذیرنده</h3>
                    </div>
                    <div class="card-body">
                        <div class="merchant-container">
                            <ul class="col-lg-12 col-sm-8 merchant-detail">
                                <li>نام پذیرنده : <b><?= \Core\controller::$data['pazirande'] ?></b></li>
                                <li>شماره پذیرنده: <b><?=\Core\controller::$data['trans_info_object']['id']?></b></li>
                                <li>آدرس وب سایت: <b class="merchantwebsite"><a
                                                href="<?= HTTPS_SERVER ?>"><?= HTTPS_SERVER ?></a></b></li>
                            </ul>
                        </div>
                        <ul class="merchant-detail price">
                            <li>مبلغ قابل پرداخت :<b class="price-number"><?= $_SESSION['amount'] ?> &nbsp; ریال</b>
                            </li>
                        </ul>
                    </div>

                </div>

            </div>
        </div>
    </section>

    <div class="keypad-container">
        <h4>صفحه کلید ایمن</h4>
        <div class="frame-umbtn">
            <button id="num1" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num2" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num3" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num4" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num5" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num6" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num7" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num8" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="num9" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="clear" type="button" class=" numpad" tabindex="-1" onclick="keyPadBackspace(event)">&#9003;
            </button>
        </div>
        <div class="frame-umbtn">
            <button id="num0" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button>
        </div>
        <div class="frame-umbtn">
            <button id="erase" type="button" class=" numpad" tabindex="-1" onclick="keypadTab()">&#8677;</button>
        </div>
    </div>


    <section class="container">
        <row class="beh-guid">
            <div class="col">
                <h4>راهنما</h4>
                <ul>
                    <li>شماره کارت: 16 رقمی بوده و بصورت 4 قسمت 4 رقمی روی کارت درج شده است.</li>
                    <li>cvv2: با طول 3 یا 4 رقم کنار شماره کارت و یا پشت کارت درج شده است.</li>
                    <li>تاریخ انقضا: شامل دو بخش ماه و سال انقضا در کنار شماره کارت درج شده است.</li>
                    <li>رمز اینترنتی: با عنوان رمز دوم و در برخی موارد با PIN2 شناخته می شود، از طریق بانک صادر کننده
                        کارت تولید شده و همچنین از طریق دستگاه های خودپرداز بانک صادر کننده قابل تهیه و یا تغییر می
                        باشد.
                    </li>
                    <li>کد امنیتی: بخشی از محتوای صفحه پرداخت است و لازم است برای ادامه فرایند خرید ، کد موجود که به
                        صورت عددی در تصویر مشخص شده است در محل پیش بینی شده درج شود.
                    </li>
                    <li>تونل پرداخت اینترنتی ویچر با استفاده از پروتکل امن http به مشتریان خود ارایه خدمت نموده و با
                        آدرس <b><?= "https://".PROJECT_CODE ?></b> شروع می شود. خواهشمند است به منظور جلوگیری از سوء استفاده های
                        احتمالی پیش از ورود هرگونه اطلاعات، آدرس موجود در بخش مرورگر وب خود را با آدرس فوق مقایسه نمایید
                        و درصورت مشاهده هر نوع مغایرت احتمالی، موضوع را با ما درمیان بگذارید.
                    </li>
                    <br><br>
                </ul>
            </div>
        </row>
    </section>
</div>
<footer class="footer">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">

            </div>
        </div>
    </div>
</footer>

<form method="post" name="returnForm" action="<?= \Core\controller::$data['return_url'] ?>">
    <input type="hidden" id="RefId" name="RefId" value="8A7713C36EAFBCDD">
    <input type="hidden" id="ResCode" name="ResCode">
    <input type="hidden" id="SaleOrderId" name="SaleOrderId" value="88703">
</form>
<form method="post" name="resultForm" action="result.mellat" accept-charset="UTF-8">
    <input type="hidden" name="RefId" value="8A7713C36EAFBCDD">
</form>

<script src="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/js/jqueryyui.js"></script>
<script>
    $(document).ready(function () {
        setCardSuggestionListHeight();
        countDownRemainingTime(<?=\Core\controller::$data['time_remaining']?>);
        $("#cardnumber").focus();
        $(document).keydown(function (e) {
            var keyCode = getEventKeyCode(e);
            if (keyCode === ctrlKey || keyCode === cmdKey) ctrlDown = true;
        }).keyup(function (e) {
            var keyCode = getEventKeyCode(e);
            if (keyCode === ctrlKey || keyCode === cmdKey) ctrlDown = false;
        });
    });

    function TurnON_OverlayLoading() {
        document.getElementById("OverlayLoading").style.display = "block";
        var i = 0;
        var elem = document.getElementById("myBar");

        if (i == 0) {
            i = 1;
            var width = 10;
            var id = setInterval(frame, 250);

            function frame() {
                if (width >= 100) {
                    clearInterval(id);
                    i = 0;
                } else {
                    width++;
                    elem.style.width = width + "%";
                    elem.innerHTML = width + "%";
                }
            }
        }
    }

    function TurnOFF_OverlayLoading() {
        document.getElementById("OverlayLoading").style.display = "none";
        var elem = document.getElementById("myBar");

        elem.style.width = "0%";
        elem.innerHTML = "0%";
    }
</script>
<script src="<?= HTTP_SERVER ?>/witcherAssets/pgwchannel/js/payment.min.js?<?= rand(1000, 9999) ?>"></script>
<script>
    encRefId = "";
    panDtoList = JSON.parse('[]');
</script>
</body>
</html>