<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header mb-5">
                    <h3 class="card-title">Welcome!</h3>
                </div>
                <div class="card-body">
                    <div class="typography-line">
                        <h1>Witcher <?=WITCHER_VERSION?> </h1>
                    </div>
                    <div class="typography-line">
                        <p>
                            Please use menu for more
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
