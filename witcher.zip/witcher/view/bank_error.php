<!DOCTYPE html>
<html>
<head>
    <title>WITCHER</title>
    <link href="<?=HTTPS_SERVER?>/witcherAssets/pgwchannel/err/css2.css" rel="stylesheet"/>
    <script src="<?=HTTPS_SERVER?>/witcherAssets/pgwchannel/err/compatibility.js"></script>
    <script src="<?=HTTPS_SERVER?>/witcherAssets/pgwchannel/err/CommonJS.js"></script>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--[if lt IE 9]>
    <script src="/witcherAssets/pgwchannel/err/html5shiv.min.js"></script>
    <script src="/witcherAssets/pgwchannel/err/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div style="margin-top: 10px">
</div>
<div>
    <div class="container text-center center-block">
        <div class="contentWrapper">
            <div class="row border-bottom" id="header" style="text-align: center">
                <div id="bank-logo" style="text-align: center;margin-bottom: 10px;">
                        <img src="<?=HTTPS_SERVER?>/witcherAssets/pgwchannel/err/logo2.png" class="img-responsive generalLogo" alt="WITCHER">
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary panel-receipt">
                        <div class="panel-heading" style="background-color: <?=\Core\controller::$data['bg-color']?>; color: #ffffff;text-align:center">
                            پرداخت اینترنتی ویچر
                        </div>
                        <div class="panel-body" style="background-color: #f0f0f0">
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="text-primary witcherMessageP">
                                       <b><?=\Core\controller::$data['msg']?></b>
                                    </p>
                                </div>
                                <div style="clear: both">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <p class="text-primary" style="text-align:center;font-weight:500;"></p>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-receipt">
                            <div class="panel  panel-warning">
                                <div class="panel-heading panel-warning" style="background-color: <?=\Core\controller::$data['bg-color']?>; color: #ffffff;border-radius:0 0 5px 5px">
                                    <br />
                                    <b></b>
                                    <br />
                                    <div style="padding: 5px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>